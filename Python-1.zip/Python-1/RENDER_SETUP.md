# 🚀 إعداد Render PostgreSQL

## الخطوات:

### 1️⃣ اذهب إلى Render
👉 https://render.com

### 2️⃣ سجل دخول أو انشئ حساب مجاني

### 3️⃣ اختر: **New +** → **PostgreSQL**

### 4️⃣ ملء البيانات:
```
Name: primebot-db (أي اسم)
Database: primebot
User: postgres
Region: اختر الأقرب لك
```

### 5️⃣ اضغط **Create Database**

### 6️⃣ انتظر البناء (~3 دقائق)

### 7️⃣ انسخ **External Database URL**
- يبدو كـ: `postgresql://user:password@host:port/dbname`

### 8️⃣ اضف في Replit:
اذهب إلى **Secrets** tab:
- **Key:** `DATABASE_URL`
- **Value:** (الرابط اللي نسخته)

### 9️⃣ أضغط **Add Secret** ✅

---

## ✅ تمام!

البوت الآن متصل بـ PostgreSQL على Render! 🎉

جميع البيانات ستُحفظ في قاعدة البيانات بدل JSON!
