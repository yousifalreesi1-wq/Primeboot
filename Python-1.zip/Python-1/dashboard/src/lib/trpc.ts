// Mock tRPC client
export const trpc = {
  // Add tRPC methods here as needed
};
