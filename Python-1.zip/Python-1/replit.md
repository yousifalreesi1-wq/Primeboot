# 🤖 PrimeBot - Dashboard Completo

## 📋 مقدمة
بوت Discord احترافي مع داشبورد كامل متكامل (مثل Probot تماماً) مع دعم اللغة العربية الكاملة.

**المالك:** ALSHARQI

---

## ✨ الميزات الرئيسية

### 1️⃣ Discord Bot (45 أمر)
- **الفئات:**
  - 🎮 ألعاب (10 أوامر)
  - 📊 معلومات (8 أوامر)
  - 🛡️ إدارة (12 أمر)
  - 🎉 أحداث (7 أوامر)
  - ⚙️ عام (8 أوامر)

- **نظام التكاتة المتقدم:**
  - Select Menu (قائمة اختيار) بدل الأزرار
  - تخصيص الخيارات
  - أزرار استقبال وإضافة عضو وإغلاق
  - Embed جميلة ومرتبة

- **أوامر الرسائل:**
  - `/sendmessage` - إرسال رسالة عادية
  - `/sendembed` - إرسال رسالة بـ Embed احترافية

### 2️⃣ Dashboard Web (React + Vite)

#### صفحات الداشبورد:
- 🏠 **الصفحة الرئيسية** - مرحباً وإحصائيات سريعة
- 📊 **الخوادم** - إدارة جميع الخوادم
- 👥 **المستخدمون** - عرض وإدارة المستخدمين
- 🎫 **التذاكر** - إدارة نظام التذاكر
- ⚙️ **الإعدادات** - جميع الإعدادات الخاصة

---

## 🚀 كيفية الاستخدام

### تشغيل البوت
```bash
npm run bot
```

### تشغيل الداشبورد
```bash
cd dashboard && npm run dev
```

### الوصول للداشبورد
- الرابط: `http://localhost:5000`
- تسجيل الدخول عبر Discord OAuth2

---

## 🛠️ البنية التقنية

### Backend (Discord.js + Express + PostgreSQL)

```
src/
├── bot.js                      # البوت الرئيسي
├── deploy-commands.js          # نشر الأوامر
├── commands/                   # جميع الأوامر (45 أمر)
├── events/                     # الأحداث
└── utils/
    ├── db.js                  # اتصال PostgreSQL
    ├── ticketdb.js            # إدارة التكاتة
    └── settingsdb.js          # إدارة الإعدادات
```

### Frontend (React + Vite + Tailwind CSS)

```
dashboard/
├── src/
│   ├── pages/                 # جميع الصفحات
│   ├── components/            # مكونات UI
│   ├── hooks/                 # React hooks
│   ├── lib/                   # مكتبات
│   └── main.tsx              # نقطة البداية
├── vite.config.ts            # إعدادات Vite
└── tailwind.config.js         # إعدادات Tailwind
```

---

## 📊 قاعدة البيانات

### PostgreSQL على Render

تم تحويل البيانات من JSON إلى PostgreSQL:

**الجداول:**
- `server_settings` - إعدادات السيرفر
- `ticket_config` - إعدادات نظام التكاتة
- `tickets` - بيانات التكاتة الفعلية

**الإعداد:**
1. اذهب: https://render.com
2. انشئ PostgreSQL Database
3. نسخ الـ `External Database URL`
4. أضفه في `.env`: `DATABASE_URL=...`

---

## 🔧 متغيرات البيئة المطلوبة

```env
# Discord Bot
DISCORD_TOKEN=your_bot_token

# Discord OAuth2
DISCORD_CLIENT_ID=your_client_id
DISCORD_CLIENT_SECRET=your_client_secret

# Database
DATABASE_URL=postgresql://user:password@host:port/dbname

# Session (لـ dashboard في المستقبل)
SESSION_SECRET=your_session_secret
```

---

## 📦 التثبيت

```bash
# تثبيت جميع الحزم
npm install

# تثبيت حزم الداشبورد
cd dashboard && npm install
```

---

## 🎯 الحالة الحالية

✅ **البوت:**
- 45 أمر شامل بالعربية
- نظام تكاتة متقدم
- متصل بـ PostgreSQL
- الجداول اتنشأت بنجاح

✅ **الداشبورد:**
- React + Vite يعمل ✓
- صفحات 5 جاهزة ✓
- Tailwind CSS جاهز ✓
- يعمل على المنفذ 5000 ✓

⏳ **في الانتظار:**
- توصيل Render PostgreSQL (من المستخدم)
- OAuth2 كامل للداشبورد
- تجميع البوت والداشبورد معاً

---

## 🔗 الروابط المهمة

- **Bot Invite:** `https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=8&scope=bot%20applications.commands`
- **Dashboard:** `http://localhost:5000` (أو Replit domain)
- **Developer Portal:** `https://discord.com/developers/applications`
- **Render:** `https://render.com`

---

## 📝 الملاحظات

- جميع التواصلات بالعربية
- التصميم احترافي مثل Probot
- قاعدة بيانات PostgreSQL موثوقة
- جميع الأوامر مع Slash Commands
- نظام الجلسات آمن (في المستقبل)

---

## 🔐 الأمان

- استخدام PostgreSQL بدل JSON
- متغيرات البيئة محفوظة بشكل آمن
- OAuth2 للـ Dashboard
- لا تخزين كلمات مرور مباشرة

